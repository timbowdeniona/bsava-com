# Logger Plugin

[![Latest Version](https://img.shields.io/github/release/php-http/logger-plugin.svg?style=flat-square)](https://github.com/php-http/logger-plugin/releases)
[![Software License](https://img.shields.io/badge/license-MIT-brightgreen.svg?style=flat-square)](LICENSE)
[![Build Status](https://img.shields.io/travis/php-http/logger-plugin.svg?style=flat-square)](https://travis-ci.org/php-http/logger-plugin)
[![Code Coverage](https://img.shields.io/scrutinizer/coverage/g/php-http/logger-plugin.svg?style=flat-square)](https://scrutinizer-ci.com/g/php-http/logger-plugin)
[![Quality Score](https://img.shields.io/scrutinizer/g/php-http/logger-plugin.svg?style=flat-square)](https://scrutinizer-ci.com/g/php-http/logger-plugin)
[![Total Downloads](https://img.shields.io/packagist/dt/php-http/logger-plugin.svg?style=flat-square)](https://packagist.org/packages/php-http/logger-plugin)

**PSR-3 Logger plugin for HTTPlug.**


## Install

Via Composer

``` bash
$ composer require php-http/logger-plugin
```


## Documentation

Please see the [official documentation](http://docs.php-http.org/en/latest/plugins/logger.html).


## Testing

``` bash
$ composer test
```


## Contributing

Please see our [contributing guide](http://docs.php-http.org/en/latest/development/contributing.html).


## Security

If you discover any security related issues, please contact us at [security@php-http.org](mailto:security@php-http.org).


## License

The MIT License (MIT). Please see [License File](LICENSE) for more information.
