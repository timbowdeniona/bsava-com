<?php

return [
    'Names' => [
        'ADP' => [
            'ADP',
            'Peseta Andorra',
        ],
        'AED' => [
            'AED',
            'Dirham Uni Emirat Arab',
        ],
        'AFA' => [
            'AFA',
            'Afgani Afganistan (1927–2002)',
        ],
        'AFN' => [
            'AFN',
            'Afgani Afganistan',
        ],
        'ALL' => [
            'ALL',
            'Lek Albania',
        ],
        'AMD' => [
            'AMD',
            'Dram Armenia',
        ],
        'ANG' => [
            'ANG',
            'Guilder Antilla Belanda',
        ],
        'AOA' => [
            'AOA',
            'Kwanza Angola',
        ],
        'AOK' => [
            'AOK',
            'Kwanza Angola (1977–1991)',
        ],
        'AON' => [
            'AON',
            'Kwanza Baru Angola (1990–2000)',
        ],
        'AOR' => [
            'AOR',
            'Kwanza Angola yang Disesuaikan Lagi (1995–1999)',
        ],
        'ARA' => [
            'ARA',
            'Austral Argentina',
        ],
        'ARL' => [
            'ARL',
            'Peso Ley Argentina (1970–1983)',
        ],
        'ARM' => [
            'ARM',
            'Peso Argentina (1881–1970)',
        ],
        'ARP' => [
            'ARP',
            'Peso Argentina (1983–1985)',
        ],
        'ARS' => [
            'ARS',
            'Peso Argentina',
        ],
        'ATS' => [
            'ATS',
            'Schilling Austria',
        ],
        'AUD' => [
            'AU$',
            'Dolar Australia',
        ],
        'AWG' => [
            'AWG',
            'Florin Aruba',
        ],
        'AZM' => [
            'AZM',
            'Manat Azerbaijan (1993–2006)',
        ],
        'AZN' => [
            'AZN',
            'Manat Azerbaijan',
        ],
        'BAD' => [
            'BAD',
            'Dinar Bosnia-Herzegovina (1992–1994)',
        ],
        'BAM' => [
            'BAM',
            'Mark Konvertibel Bosnia-Herzegovina',
        ],
        'BAN' => [
            'BAN',
            'Dinar Baru Bosnia-Herzegovina (1994–1997)',
        ],
        'BBD' => [
            'BBD',
            'Dolar Barbados',
        ],
        'BDT' => [
            'BDT',
            'Taka Bangladesh',
        ],
        'BEC' => [
            'BEC',
            'Franc Belgia (konvertibel)',
        ],
        'BEF' => [
            'BEF',
            'Franc Belgia',
        ],
        'BEL' => [
            'BEL',
            'Franc Belgia (keuangan)',
        ],
        'BGL' => [
            'BGL',
            'Hard Lev Bulgaria',
        ],
        'BGM' => [
            'BGM',
            'Socialist Lev Bulgaria',
        ],
        'BGN' => [
            'BGN',
            'Lev Bulgaria',
        ],
        'BGO' => [
            'BGO',
            'Lev Bulgaria (1879–1952)',
        ],
        'BHD' => [
            'BHD',
            'Dinar Bahrain',
        ],
        'BIF' => [
            'BIF',
            'Franc Burundi',
        ],
        'BMD' => [
            'BMD',
            'Dolar Bermuda',
        ],
        'BND' => [
            'BND',
            'Dolar Brunei',
        ],
        'BOB' => [
            'BOB',
            'Boliviano',
        ],
        'BOL' => [
            'BOL',
            'Boliviano Bolivia (1863–1963)',
        ],
        'BOP' => [
            'BOP',
            'Peso Bolivia',
        ],
        'BOV' => [
            'BOV',
            'Mvdol Bolivia',
        ],
        'BRB' => [
            'BRB',
            'Cruzeiro Baru Brasil (1967–1986)',
        ],
        'BRC' => [
            'BRC',
            'Cruzado Brasil (1986–1989)',
        ],
        'BRE' => [
            'BRE',
            'Cruzeiro Brasil (1990–1993)',
        ],
        'BRL' => [
            'R$',
            'Real Brasil',
        ],
        'BRN' => [
            'BRN',
            'Cruzado Baru Brasil (1989–1990)',
        ],
        'BRR' => [
            'BRR',
            'Cruzeiro Brasil (1993–1994)',
        ],
        'BRZ' => [
            'BRZ',
            'Cruzeiro Brasil (1942–1967)',
        ],
        'BSD' => [
            'BSD',
            'Dolar Bahama',
        ],
        'BTN' => [
            'BTN',
            'Ngultrum Bhutan',
        ],
        'BUK' => [
            'BUK',
            'Kyat Burma',
        ],
        'BWP' => [
            'BWP',
            'Pula Botswana',
        ],
        'BYB' => [
            'BYB',
            'Rubel Baru Belarus (1994–1999)',
        ],
        'BYN' => [
            'BYN',
            'Rubel Belarusia',
        ],
        'BYR' => [
            'BYR',
            'Rubel Belarusia (2000–2016)',
        ],
        'BZD' => [
            'BZD',
            'Dolar Belize',
        ],
        'CAD' => [
            'CA$',
            'Dolar Kanada',
        ],
        'CDF' => [
            'CDF',
            'Franc Kongo',
        ],
        'CHE' => [
            'CHE',
            'Euro WIR',
        ],
        'CHF' => [
            'CHF',
            'Franc Swiss',
        ],
        'CHW' => [
            'CHW',
            'Franc WIR',
        ],
        'CLE' => [
            'CLE',
            'Escudo Cile',
        ],
        'CLF' => [
            'CLF',
            'Satuan Hitung (UF) Cile',
        ],
        'CLP' => [
            'CLP',
            'Peso Cile',
        ],
        'CNH' => [
            'CNH',
            'Yuan Tiongkok (luar negeri)',
        ],
        'CNY' => [
            'CN¥',
            'Yuan Tiongkok',
        ],
        'COP' => [
            'COP',
            'Peso Kolombia',
        ],
        'COU' => [
            'COU',
            'Unit Nilai Nyata Kolombia',
        ],
        'CRC' => [
            'CRC',
            'Colon Kosta Rika',
        ],
        'CSD' => [
            'CSD',
            'Dinar Serbia (2002–2006)',
        ],
        'CSK' => [
            'CSK',
            'Hard Koruna Cheska',
        ],
        'CUC' => [
            'CUC',
            'Peso Konvertibel Kuba',
        ],
        'CUP' => [
            'CUP',
            'Peso Kuba',
        ],
        'CVE' => [
            'CVE',
            'Escudo Tanjung Verde',
        ],
        'CYP' => [
            'CYP',
            'Pound Siprus',
        ],
        'CZK' => [
            'CZK',
            'Koruna Ceko',
        ],
        'DDM' => [
            'DDM',
            'Mark Jerman Timur',
        ],
        'DEM' => [
            'DEM',
            'Mark Jerman',
        ],
        'DJF' => [
            'DJF',
            'Franc Jibuti',
        ],
        'DKK' => [
            'DKK',
            'Krone Denmark',
        ],
        'DOP' => [
            'DOP',
            'Peso Dominika',
        ],
        'DZD' => [
            'DZD',
            'Dinar Aljazair',
        ],
        'ECS' => [
            'ECS',
            'Sucre Ekuador',
        ],
        'ECV' => [
            'ECV',
            'Satuan Nilai Tetap Ekuador',
        ],
        'EEK' => [
            'EEK',
            'Kroon Estonia',
        ],
        'EGP' => [
            'EGP',
            'Pound Mesir',
        ],
        'ERN' => [
            'ERN',
            'Nakfa Eritrea',
        ],
        'ESA' => [
            'ESA',
            'Peseta Spanyol (akun)',
        ],
        'ESB' => [
            'ESB',
            'Peseta Spanyol (konvertibel)',
        ],
        'ESP' => [
            'ESP',
            'Peseta Spanyol',
        ],
        'ETB' => [
            'ETB',
            'Birr Etiopia',
        ],
        'EUR' => [
            '€',
            'Euro',
        ],
        'FIM' => [
            'FIM',
            'Markka Finlandia',
        ],
        'FJD' => [
            'FJD',
            'Dolar Fiji',
        ],
        'FKP' => [
            'FKP',
            'Pound Kepulauan Falkland',
        ],
        'FRF' => [
            'FRF',
            'Franc Prancis',
        ],
        'GBP' => [
            '£',
            'Pound Inggris',
        ],
        'GEK' => [
            'GEK',
            'Kupon Larit Georgia',
        ],
        'GEL' => [
            'GEL',
            'Lari Georgia',
        ],
        'GHC' => [
            'GHC',
            'Cedi Ghana (1979–2007)',
        ],
        'GHS' => [
            'GHS',
            'Cedi Ghana',
        ],
        'GIP' => [
            'GIP',
            'Pound Gibraltar',
        ],
        'GMD' => [
            'GMD',
            'Dalasi Gambia',
        ],
        'GNF' => [
            'GNF',
            'Franc Guinea',
        ],
        'GNS' => [
            'GNS',
            'Syli Guinea',
        ],
        'GQE' => [
            'GQE',
            'Ekuele Guinea Ekuatorial',
        ],
        'GRD' => [
            'GRD',
            'Drachma Yunani',
        ],
        'GTQ' => [
            'GTQ',
            'Quetzal Guatemala',
        ],
        'GWE' => [
            'GWE',
            'Escudo Guinea Portugal',
        ],
        'GWP' => [
            'GWP',
            'Peso Guinea-Bissau',
        ],
        'GYD' => [
            'GYD',
            'Dolar Guyana',
        ],
        'HKD' => [
            'HK$',
            'Dolar Hong Kong',
        ],
        'HNL' => [
            'HNL',
            'Lempira Honduras',
        ],
        'HRD' => [
            'HRD',
            'Dinar Kroasia',
        ],
        'HRK' => [
            'HRK',
            'Kuna Kroasia',
        ],
        'HTG' => [
            'HTG',
            'Gourde Haiti',
        ],
        'HUF' => [
            'HUF',
            'Forint Hungaria',
        ],
        'IDR' => [
            'Rp',
            'Rupiah Indonesia',
        ],
        'IEP' => [
            'IEP',
            'Pound Irlandia',
        ],
        'ILP' => [
            'ILP',
            'Pound Israel',
        ],
        'ILR' => [
            'ILR',
            'Shekel Israel',
        ],
        'ILS' => [
            '₪',
            'Shekel Baru Israel',
        ],
        'INR' => [
            'Rs',
            'Rupee India',
        ],
        'IQD' => [
            'IQD',
            'Dinar Irak',
        ],
        'IRR' => [
            'IRR',
            'Rial Iran',
        ],
        'ISJ' => [
            'ISJ',
            'Krona Islandia (1918–1981)',
        ],
        'ISK' => [
            'ISK',
            'Krona Islandia',
        ],
        'ITL' => [
            'ITL',
            'Lira Italia',
        ],
        'JMD' => [
            'JMD',
            'Dolar Jamaika',
        ],
        'JOD' => [
            'JOD',
            'Dinar Yordania',
        ],
        'JPY' => [
            'JP¥',
            'Yen Jepang',
        ],
        'KES' => [
            'KES',
            'Shilling Kenya',
        ],
        'KGS' => [
            'KGS',
            'Som Kirgizstan',
        ],
        'KHR' => [
            'KHR',
            'Riel Kamboja',
        ],
        'KMF' => [
            'KMF',
            'Franc Komoro',
        ],
        'KPW' => [
            'KPW',
            'Won Korea Utara',
        ],
        'KRH' => [
            'KRH',
            'Hwan Korea Selatan (1953–1962)',
        ],
        'KRO' => [
            'KRO',
            'Won Korea Selatan (1945–1953)',
        ],
        'KRW' => [
            '₩',
            'Won Korea Selatan',
        ],
        'KWD' => [
            'KWD',
            'Dinar Kuwait',
        ],
        'KYD' => [
            'KYD',
            'Dolar Kepulauan Cayman',
        ],
        'KZT' => [
            'KZT',
            'Tenge Kazakhstan',
        ],
        'LAK' => [
            'LAK',
            'Kip Laos',
        ],
        'LBP' => [
            'LBP',
            'Pound Lebanon',
        ],
        'LKR' => [
            'LKR',
            'Rupee Sri Lanka',
        ],
        'LRD' => [
            'LRD',
            'Dolar Liberia',
        ],
        'LSL' => [
            'LSL',
            'Loti Lesotho',
        ],
        'LTL' => [
            'LTL',
            'Litas Lituania',
        ],
        'LTT' => [
            'LTT',
            'Talonas Lituania',
        ],
        'LUC' => [
            'LUC',
            'Franc Konvertibel Luksemburg',
        ],
        'LUF' => [
            'LUF',
            'Franc Luksemburg',
        ],
        'LUL' => [
            'LUL',
            'Financial Franc Luksemburg',
        ],
        'LVL' => [
            'LVL',
            'Lats Latvia',
        ],
        'LVR' => [
            'LVR',
            'Rubel Latvia',
        ],
        'LYD' => [
            'LYD',
            'Dinar Libya',
        ],
        'MAD' => [
            'MAD',
            'Dirham Maroko',
        ],
        'MAF' => [
            'MAF',
            'Franc Maroko',
        ],
        'MCF' => [
            'MCF',
            'Franc Monegasque',
        ],
        'MDC' => [
            'MDC',
            'Cupon Moldova',
        ],
        'MDL' => [
            'MDL',
            'Leu Moldova',
        ],
        'MGA' => [
            'MGA',
            'Ariary Madagaskar',
        ],
        'MGF' => [
            'MGF',
            'Franc Malagasi',
        ],
        'MKD' => [
            'MKD',
            'Denar Makedonia',
        ],
        'MKN' => [
            'MKN',
            'Denar Makedonia (1992–1993)',
        ],
        'MLF' => [
            'MLF',
            'Franc Mali',
        ],
        'MMK' => [
            'MMK',
            'Kyat Myanmar',
        ],
        'MNT' => [
            'MNT',
            'Tugrik Mongolia',
        ],
        'MOP' => [
            'MOP',
            'Pataca Makau',
        ],
        'MRO' => [
            'MRO',
            'Ouguiya Mauritania (1973–2017)',
        ],
        'MRU' => [
            'MRU',
            'Ouguiya Mauritania',
        ],
        'MTL' => [
            'MTL',
            'Lira Malta',
        ],
        'MTP' => [
            'MTP',
            'Pound Malta',
        ],
        'MUR' => [
            'MUR',
            'Rupee Mauritius',
        ],
        'MVP' => [
            'MVP',
            'Rufiyaa Maladewa (1947–1981)',
        ],
        'MVR' => [
            'MVR',
            'Rufiyaa Maladewa',
        ],
        'MWK' => [
            'MWK',
            'Kwacha Malawi',
        ],
        'MXN' => [
            'MX$',
            'Peso Meksiko',
        ],
        'MXP' => [
            'MXP',
            'Peso Silver Meksiko (1861–1992)',
        ],
        'MXV' => [
            'MXV',
            'Unit Investasi Meksiko',
        ],
        'MYR' => [
            'MYR',
            'Ringgit Malaysia',
        ],
        'MZE' => [
            'MZE',
            'Escudo Mozambik',
        ],
        'MZM' => [
            'MZM',
            'Metical Mozambik (1980–2006)',
        ],
        'MZN' => [
            'MZN',
            'Metical Mozambik',
        ],
        'NAD' => [
            'NAD',
            'Dolar Namibia',
        ],
        'NGN' => [
            'NGN',
            'Naira Nigeria',
        ],
        'NIC' => [
            'NIC',
            'Cordoba Nikaragua (1988–1991)',
        ],
        'NIO' => [
            'NIO',
            'Cordoba Nikaragua',
        ],
        'NLG' => [
            'NLG',
            'Guilder Belanda',
        ],
        'NOK' => [
            'NOK',
            'Krone Norwegia',
        ],
        'NPR' => [
            'NPR',
            'Rupee Nepal',
        ],
        'NZD' => [
            'NZ$',
            'Dolar Selandia Baru',
        ],
        'OMR' => [
            'OMR',
            'Rial Oman',
        ],
        'PAB' => [
            'PAB',
            'Balboa Panama',
        ],
        'PEI' => [
            'PEI',
            'Inti Peru',
        ],
        'PEN' => [
            'PEN',
            'Sol Peru',
        ],
        'PES' => [
            'PES',
            'Sol Peru (1863–1965)',
        ],
        'PGK' => [
            'PGK',
            'Kina Papua Nugini',
        ],
        'PHP' => [
            'PHP',
            'Peso Filipina',
        ],
        'PKR' => [
            'PKR',
            'Rupee Pakistan',
        ],
        'PLN' => [
            'PLN',
            'Zloty Polandia',
        ],
        'PLZ' => [
            'PLZ',
            'Zloty Polandia (1950–1995)',
        ],
        'PTE' => [
            'PTE',
            'Escudo Portugal',
        ],
        'PYG' => [
            'PYG',
            'Guarani Paraguay',
        ],
        'QAR' => [
            'QAR',
            'Rial Qatar',
        ],
        'RHD' => [
            'RHD',
            'Dolar Rhodesia',
        ],
        'ROL' => [
            'ROL',
            'Leu Rumania (1952–2006)',
        ],
        'RON' => [
            'RON',
            'Leu Rumania',
        ],
        'RSD' => [
            'RSD',
            'Dinar Serbia',
        ],
        'RUB' => [
            'RUB',
            'Rubel Rusia',
        ],
        'RUR' => [
            'RUR',
            'Rubel Rusia (1991–1998)',
        ],
        'RWF' => [
            'RWF',
            'Franc Rwanda',
        ],
        'SAR' => [
            'SAR',
            'Riyal Arab Saudi',
        ],
        'SBD' => [
            'SBD',
            'Dolar Kepulauan Solomon',
        ],
        'SCR' => [
            'SCR',
            'Rupee Seychelles',
        ],
        'SDD' => [
            'SDD',
            'Dinar Sudan (1992–2007)',
        ],
        'SDG' => [
            'SDG',
            'Pound Sudan',
        ],
        'SDP' => [
            'SDP',
            'Pound Sudan (1957–1998)',
        ],
        'SEK' => [
            'SEK',
            'Krona Swedia',
        ],
        'SGD' => [
            'SGD',
            'Dolar Singapura',
        ],
        'SHP' => [
            'SHP',
            'Pound Saint Helena',
        ],
        'SIT' => [
            'SIT',
            'Tolar Slovenia',
        ],
        'SKK' => [
            'SKK',
            'Koruna Slovakia',
        ],
        'SLE' => [
            'SLE',
            'Leone Sierra Leone',
        ],
        'SLL' => [
            'SLL',
            'Leone Sierra Leone (1964—2022)',
        ],
        'SOS' => [
            'SOS',
            'Shilling Somalia',
        ],
        'SRD' => [
            'SRD',
            'Dolar Suriname',
        ],
        'SRG' => [
            'SRG',
            'Guilder Suriname',
        ],
        'SSP' => [
            'SSP',
            'Pound Sudan Selatan',
        ],
        'STD' => [
            'STD',
            'Dobra Sao Tome dan Principe (1977–2017)',
        ],
        'STN' => [
            'STN',
            'Dobra Sao Tome dan Principe',
        ],
        'SUR' => [
            'SUR',
            'Rubel Soviet',
        ],
        'SVC' => [
            'SVC',
            'Colon El Savador',
        ],
        'SYP' => [
            'SYP',
            'Pound Suriah',
        ],
        'SZL' => [
            'SZL',
            'Lilangeni Swaziland',
        ],
        'THB' => [
            '฿',
            'Baht Thailand',
        ],
        'TJR' => [
            'TJR',
            'Rubel Tajikistan',
        ],
        'TJS' => [
            'TJS',
            'Somoni Tajikistan',
        ],
        'TMM' => [
            'TMM',
            'Manat Turkmenistan (1993–2009)',
        ],
        'TMT' => [
            'TMT',
            'Manat Turkmenistan',
        ],
        'TND' => [
            'TND',
            'Dinar Tunisia',
        ],
        'TOP' => [
            'TOP',
            'Paʻanga Tonga',
        ],
        'TPE' => [
            'TPE',
            'Escudo Timor',
        ],
        'TRL' => [
            'TRL',
            'Lira Turki (1922–2005)',
        ],
        'TRY' => [
            'TRY',
            'Lira Turki',
        ],
        'TTD' => [
            'TTD',
            'Dolar Trinidad dan Tobago',
        ],
        'TWD' => [
            'NT$',
            'Dolar Baru Taiwan',
        ],
        'TZS' => [
            'TZS',
            'Shilling Tanzania',
        ],
        'UAH' => [
            'UAH',
            'Hryvnia Ukraina',
        ],
        'UAK' => [
            'UAK',
            'Karbovanet Ukraina',
        ],
        'UGS' => [
            'UGS',
            'Shilling Uganda (1966–1987)',
        ],
        'UGX' => [
            'UGX',
            'Shilling Uganda',
        ],
        'USD' => [
            'US$',
            'Dolar Amerika Serikat',
        ],
        'USN' => [
            'USN',
            'Dolar AS (Hari berikutnya)',
        ],
        'USS' => [
            'USS',
            'Dolar AS (Hari yang sama)',
        ],
        'UYI' => [
            'UYI',
            'Peso Uruguay (Unit Diindeks)',
        ],
        'UYP' => [
            'UYP',
            'Peso Uruguay (1975–1993)',
        ],
        'UYU' => [
            'UYU',
            'Peso Uruguay',
        ],
        'UZS' => [
            'UZS',
            'Som Uzbekistan',
        ],
        'VEB' => [
            'VEB',
            'Bolivar Venezuela (1871–2008)',
        ],
        'VEF' => [
            'VEF',
            'Bolivar Venezuela (2008–2018)',
        ],
        'VES' => [
            'VES',
            'Bolivar Venezuela',
        ],
        'VND' => [
            '₫',
            'Dong Vietnam',
        ],
        'VNN' => [
            'VNN',
            'Dong Vietnam (1978–1985)',
        ],
        'VUV' => [
            'VUV',
            'Vatu Vanuatu',
        ],
        'WST' => [
            'WST',
            'Tala Samoa',
        ],
        'XAF' => [
            'FCFA',
            'Franc CFA Afrika Tengah',
        ],
        'XCD' => [
            'EC$',
            'Dolar Karibia Timur',
        ],
        'XCG' => [
            'Cg.',
            'Guilder Karibia',
        ],
        'XEU' => [
            'XEU',
            'Satuan Mata Uang Eropa',
        ],
        'XFO' => [
            'XFO',
            'Franc Gold Perancis',
        ],
        'XFU' => [
            'XFU',
            'Franc UIC Perancis',
        ],
        'XOF' => [
            'F CFA',
            'Franc CFA Afrika Barat',
        ],
        'XPF' => [
            'CFPF',
            'Franc CFP',
        ],
        'XRE' => [
            'XRE',
            'Dana RINET',
        ],
        'YDD' => [
            'YDD',
            'Dinar Yaman',
        ],
        'YER' => [
            'YER',
            'Rial Yaman',
        ],
        'YUD' => [
            'YUD',
            'Hard Dinar Yugoslavia (1966–1990)',
        ],
        'YUM' => [
            'YUM',
            'Dinar Baru Yugoslavia (1994–2002)',
        ],
        'YUN' => [
            'YUN',
            'Dinar Konvertibel Yugoslavia (1990–1992)',
        ],
        'YUR' => [
            'YUR',
            'Dinar Reformasi Yugoslavia (1992–1993)',
        ],
        'ZAL' => [
            'ZAL',
            'Rand Afrika Selatan (Keuangan)',
        ],
        'ZAR' => [
            'ZAR',
            'Rand Afrika Selatan',
        ],
        'ZMK' => [
            'ZMK',
            'Kwacha Zambia (1968–2012)',
        ],
        'ZMW' => [
            'ZMW',
            'Kwacha Zambia',
        ],
        'ZRN' => [
            'ZRN',
            'Zaire Baru Zaire (1993–1998)',
        ],
        'ZRZ' => [
            'ZRZ',
            'Zaire Zaire (1971–1993)',
        ],
        'ZWD' => [
            'ZWD',
            'Dolar Zimbabwe (1980–2008)',
        ],
        'ZWG' => [
            'ZWG',
            'Emas Zimbabwe',
        ],
        'ZWL' => [
            'ZWL',
            'Dolar Zimbabwe (2009)',
        ],
        'ZWR' => [
            'ZWR',
            'Dolar Zimbabwe (2008)',
        ],
    ],
];
